package mc322.lab06;

public class AppMundoWumpus {
	
	public static void main(String[] args) {
		String Arquivo = "C:\\Users\\muril\\Desktop\\TimECA (mc322)\\lab06\\data\\arq0001.csv";
		new MontadorCaverna(Arquivo);
	}

}
